#define BUFSIZE 32
#define EOF_code BUFSIZE+6